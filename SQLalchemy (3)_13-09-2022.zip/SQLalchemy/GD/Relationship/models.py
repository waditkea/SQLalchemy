from GD import db
class Student(db.Model):
    __tablename__="Student1"
    id=db.Column("ID",db.Integer,primary_key=True,autoincrement=True)
    name = db.Column("Name",db.String(100), nullable=False)
    address = db.Column("Address",db.String(200), nullable=False)

    def __repr__(self):
        return {"id":self.id,"name":self.name,"address":self.address}