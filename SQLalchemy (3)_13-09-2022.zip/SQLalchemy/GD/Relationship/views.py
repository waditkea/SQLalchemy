from flask import Blueprint

mod=Blueprint("relationship",__name__)

